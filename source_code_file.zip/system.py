import pandas as pd
import os
import torch
from llama_index.core import QueryBundle, VectorStoreIndex, StorageContext
from llama_index.core.schema import TextNode
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.vector_stores.chroma import ChromaVectorStore
from llama_index.llms.huggingface import HuggingFaceLLM
from llama_index.core.postprocessor import LLMRerank
from llama_index.core.postprocessor import SimilarityPostprocessor
from llama_index.core import VectorStoreIndex, StorageContext
from llama_index.core.vector_stores import MetadataFilters
from llama_index.core import Settings

from transformers import AutoTokenizer, pipeline
import chromadb
from tqdm import tqdm
import time
import together

from config import VECTOR_STORE_DIR, EMBED_MODEL_NAME, LLM_MODEL_NAME

RETRIEVER_SIMILARITY_TOP_K: int = 5
RERANKER_CHOICE_BATCH_SIZE: int = 3
RERANKER_TOP_N: int = 1

# TODO: implement RAG pipline with metadata filtering and reranking.
# When initializing different object in the constructor, please make
# the objects protected, which is achieved by underscoring the beginning
# of the object, as in the example with the embedding model:
# self._embed_model = ...

# We suggest sticking to the provided template for we believe it to be
# the simplest implementation way. Please, provide explanation if you
# find it necessary to change template.


class RAGSystem:
    def __init__(self):
        # Check if GPU is available
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        print(f"Using device: {self.device}")
        
        # Initialize embedding model given EMBED_MODEL_NAME.
        try:
            self._embed_model = HuggingFaceEmbedding(model_name=EMBED_MODEL_NAME)  # TODO
        except RuntimeError as e:
            print(f"Error loading embedding model on GPU: {e}")
            print("Falling back to CPU...")
            self.device = "cpu"
            self._embed_model = HuggingFaceEmbedding(
                model_name=EMBED_MODEL_NAME,
                device="cpu",
            )

        # Initialize a vector database from the existing collection
        # in VECTOR_STORE_DIR and a corresponding vector store index.
        # We recommend ChromaDB. Embedding model should be the same
        # as for storing the nodes.
        # TODO

        # Initialize the client first
        self._chroma_client = chromadb.PersistentClient(path=VECTOR_STORE_DIR)

        # Get existing collection
        self._collection = self._chroma_client.get_collection("financial_filings")

        # Initialize 
        self._vector_store = ChromaVectorStore(chroma_collection=self._collection)
        storage_context = StorageContext.from_defaults(vector_store=self._vector_store)
        self._vector_index = VectorStoreIndex.from_vector_store(
            vector_store=self._vector_store,
            embed_model=self._embed_model
        )

        # Initialize LLM given LLM_MODEL_NAME.
        # Tip: for the pipeline to work correctly, it is likely
        # you will need to create a tokenizer for the model.
        # We suggest looking into AutoTokenizer.
        # TODO
        
        # As I will directly use together.Completion.create(), I donnot need to initialize LLM
        # Here I will set up my together api
        # TODO
        os.environ['TOGETHER_API_KEY'] = 'Replace_with_Your_Own_TogetherAI_API_Key'
        api_key = os.getenv("TOGETHER_API_KEY")
        if not api_key:
            raise ValueError("TOGETHER_API_KEY not found in environment variables")
        
        together.api_key = api_key

        # Initialize reranker. We suggest LLM-based reranker with
        # RERANKER_CHOICE_BATCH_SIZE nodes to consider from the retriever and
        # RERANKER_TOP_N documents to return.
        # TODO

        self._reranker = SimilarityPostprocessor(
            choice_batch_size=RERANKER_CHOICE_BATCH_SIZE,
            top_n=RERANKER_TOP_N,
        )

    def respond(self, query: str, ticker: str, year: str) -> tuple[str, TextNode]:
        """
        Given a questy, a ticker and a year, should return a response
        to the provided query for the given company in the given year and
        the most relevant node.

        Process query and return response with most relevant node.

        Args:
           query (str): The user's question
           ticker (str): Company ticker symbol
           year (str): Year to query
           
        Returns:
           tuple[str, TextNode]: Generated response and most relevant node
        """
        # Convert the given query string to a query bundle (most likely
        # required for correct work).
        query_bundle = QueryBundle(query)

        # Initialize metadata filters.
        # TODO

        # print(f"Searching for {ticker} documents from {year}...")

        metadata_filters = MetadataFilters(
                filters=[
                    {"key": "ticker", "value": ticker},
                    {"key": "year", "value": year}
                ]
            )

        # Initialize retriever from the vector store index
        # with the filters above and RETRIEVER_SIMILARITY_TOP_K.
        # TODO

        retriever = self._vector_index.as_retriever(
            similarity_top_k=RETRIEVER_SIMILARITY_TOP_K,
            filters=metadata_filters
        )

        nodes = retriever.retrieve(query_bundle)

        filtered_nodes = [
            node for node in nodes 
            if node.metadata.get("ticker") == ticker and 
               node.metadata.get("year") == year
        ]
 
        if not filtered_nodes:
            return "No relevant information found for this company and year.", None

        # Apply the reranker to the retrieved nodes and get
        # the best one.
        # TODO
        reranked_nodes = self._reranker.postprocess_nodes(
            filtered_nodes,
            query_bundle
        )
 
        if len(reranked_nodes) == 0:
            return "Failed to rank the retrieved documents.", None
                
        top_nodes = reranked_nodes[:2]

        # Merge the reranked nodes with the query and give it
        # to the LLM to get the response.
        # TODO

        # Generate response using context
        # Combine the top node texts for context
        context_text = " ".join(node.text for node in top_nodes if node.text)
        # max_context_length = 4096
        # context_text = context_text[:max_context_length]

        prompt = (
            f"Based on the following context, answer the question: {query}\n\n"
            f"Context from {ticker}'s {year} report:\n{context_text}\n\n"
            "Answer the question concisely in one sentence:"
        )

        for attempt in range(5):  # Retry up to 5 times
            try:
                response = together.Completion.create(
                    model=LLM_MODEL_NAME,
                    prompt=prompt,
                    max_tokens=100,
                    temperature=0.7,
                    top_p=0.9,
                    stop=["\n"]
                )
                response_text = response.choices[0].text.strip()
                return response_text, top_nodes
            except Exception as e:
                print(f"Attempt {attempt + 1} failed: {e}", flush=True)
                time.sleep(2 ** attempt)  # Exponential backoff
        return "LLM API failed after multiple attempts.", []


if __name__ == '__main__':
    # TODO: come up with 2 questions for each ticker based on the documents,
    # and evaluate the quality of both the retriever by the most relevant node provided
    # and the response. Implementing automatic evaluation techniques is not required,
    # we expect to see detailed analysis of the manual evaluation.
    
    # Test questions for each ticker
    questions = [
        [
            {"query": "What is the total revenue of this company for this fiscal year?", "year": "2019"},
            {"query": "What is the gross profit of this company for this fiscal year?", "year": "2019"}
        ],
        [
            {"query": "Who is the Chairman of the Board of this company?", "year": "2015"},
            {"query": "What are the main risk factors of this company?", "year": "2015"}
        ],
        [
            {"query": "What are the main products of this company?", "year": "2017"},
            {"query": "What are the main revenue sources of this company?", "year": "2017"}
        ],
        [
            {"query": "What is the company's total debt for this fiscal year?", "year": "2010"},
            {"query": "What are the primary costs affecting the company's profitability?", "year": "2010"}
        ],
        [
            {"query": "What is the company's cash flow from operations for this fiscal year?", "year": "2013"},
            {"query": "What is the company's investment strategy mentioned in this year's report?", "year": "2013"}
        ],
        [
            {"query": "What are the key markets or regions where this company operates?", "year": "2019"},
            {"query": "What are the company's earnings per share (EPS) as reported?", "year": "2019"}
        ],
        [
            {"query": "What are the company's primary competitive advantages mentioned in the 10-K?", "year": "2018"},
            {"query": "What is the company's operating income for this fiscal year?", "year": "2018"}
        ],
        [
            {"query": "What is the total asset of this company for this fiscal year?", "year": "2017"},
            {"query": "What is the total shareholder's equity of this company for this fiscal year?", "year": "2017"}
        ],
        [
            {"query": "What is the net income of this company for this fiscal year?", "year": "2015"},
            {"query": "What is the fiscal year with year end of this 10K report?", "year": "2015"}
        ],
        [
            {"query": "What are the company's main subsidiaries mentioned in the 10-K?", "year": "2015"},
            {"query": "What are the company's capital expenditures for the reporting period?", "year": "2015"}
        ],
    ]

    ticker_file = "sampled_tickers.txt"
    with open(ticker_file, "r") as file:
        tickers = [line.strip() for line in file.readlines()]

    # Combine tickers with the questions
    test_cases = {ticker: questions[i % len(questions)] for i, ticker in enumerate(tickers)}

    # Initialize the RAG system
    system = RAGSystem()

    # Save results dynamically based on test cases
    results = []
    for ticker, queries in test_cases.items():
        for case in queries:
            query = case["query"]
            year = case["year"]
            response, nodes = system.respond(query, ticker, year)

            source_text = "\n\n".join(node.text for node in nodes if node.text)

            results.append({
                "ticker": ticker,
                "query": query,
                "year": year,
                "response": response,
                "retrieved nodes": source_text,
            })

            # # Print results to console
            # print(f"\nTicker: {ticker}")
            # print(f"Year: {year}")
            # print(f"Query: {query}")
            # print(f"Response: {response}")
            # print(f"Retrieved Nodes: {source_text[:500]}...\n")  # Truncate for readability

    # Save the results to a DataFrame and output to CSV
    results_df = pd.DataFrame(results)
    results_df.to_csv("query_results.csv", index=False, encoding="utf-8")

# Possible scores:
# [20 pts]        Basic RAG implemented, without metadata filtering
#                 and reranking.
# [+10 pts]       Metadata filtering implemented.
# [+5 pts]        Reranking implemented.
# [up to +10 pts] Manual evaluation implemented and analyzed.