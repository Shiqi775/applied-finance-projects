import streamlit as st
from system import RAGSystem
import pandas as pd
import os
import traceback

# TODO: develop a Streamlit-based web application that enables
# users to ask questions about a company's financial statements
# for a specific year. The app should include dropdown menus for
# selecting the company ticker and year, alongside a text box for
# entering queries. Responses will be generated using a prebuilt
# Retrieval-Augmented Generation (RAG) pipeline.

# The application must be robust and should never crash, handling
# all errors gracefully with user-friendly messages. It should
# ensure a smooth user experience, even when unexpected issues
# occur during execution.

def load_tickers():
    """Load available tickers from file"""
    try:
        with open("sampled_tickers.txt", 'r') as file:
            return [line.strip() for line in file.readlines()]
    except Exception as e:
        st.error(f"Error loading tickers: {str(e)}")
        return []

def load_years():
    """Generate or load a list of available years dynamically"""
    return [str(year) for year in range(2010, 2020)]

def initialize_rag_system():
    """Initialize RAG system with error handling"""
    try:
        if 'rag_system' not in st.session_state:
            st.session_state.rag_system = RAGSystem()
        return st.session_state.rag_system
    except Exception as e:
        st.error(f"Failed to initialize RAG system: {str(e)}")
        st.error("Please check your configuration and try again.")
        return None

def main():
    st.title("Financial Statement Question-Answering System")
    
    # Initialize system
    rag_system = initialize_rag_system()
    if not rag_system:
        st.stop()
    
    # Sidebar for configuration
    with st.sidebar:
        st.header("Query Configuration")
        
        # Load and display ticker selection
        tickers = load_tickers()
        if not tickers:
            st.error("No tickers available")
            st.stop()
            
        ticker = st.selectbox(
            "Select Company Ticker",
            options=tickers
        )
        
        # Year selection
        years = load_years()
        if not years:
            st.error("No years available")
            st.stop()
        
        year = st.selectbox(
            "Select Year",
            options=years
        )
        
        # Display system status
        st.markdown("---")
        st.markdown("### System Status")
        st.markdown(f"Using device: {rag_system.device}")
        
    # Main content area
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.markdown("### Ask Questions")
        query = st.text_area(
            "Enter your question about the financial statements:",
            placeholder="e.g., What was the company's revenue?"
        )
        
        submit = st.button("Submit Question")
        
    # Handle query submission
    if submit and query:
        try:
            with st.spinner("Processing your question..."):
                response, node = rag_system.respond(query, ticker, year)
                
                # Display response
                st.markdown("### Response")
                st.write(response)
                
                # Display source information
                with col2:
                    st.markdown("### Source Information")
                    st.markdown("*Extracted from document:*")
                    if node:
                        if isinstance(node, list):  # Check if node is a list
                            # Combine texts from all nodes
                            source_text = "\n\n".join(n.text for n in node if n.text)
                            st.markdown(f"```\n{source_text[:500]}...\n```")  # Truncate if too long
                        elif hasattr(node, "text"):  # If it's a single node
                            st.markdown(f"```\n{node.text[:500]}...\n```")
                        else:
                            st.warning("No source text available")
                    else:
                        st.warning("No source document available")
        
        except Exception as e:
            st.error("An error occurred while processing your question.")
            st.error(f"Error details: {str(e)}")
            if st.checkbox("Show detailed error trace"):
                st.code(traceback.format_exc())
    
    # Additional Information
    with st.expander("Usage Tips"):
        st.markdown("""
        - Select a company ticker from the sidebar
        - Choose the year of interest
        - Enter your question about the financial statements
        - Click 'Submit Question' to get an answer
        - View the source information to understand where the answer came from
        """)

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        st.error("Application encountered an error. Please refresh the page.")
        st.error(f"Error details: {str(e)}")
        if st.checkbox("Show detailed error trace"):
            st.code(traceback.format_exc())

